// routes/asistentes.routes.js
import { Router } from "express";
import { AsistentesController } from "../controllers/asistentes.controller.js";

const router = Router();

// Obtener todos los asistentes
router.get("/", AsistentesController.getAll);

// Obtener asistente por ID
router.get("/:id", AsistentesController.getById);

// Crear asistente (registrar usuario en un evento)
router.post("/", AsistentesController.create);

// Actualizar inscripción (estado, usuario, evento)
router.put("/:id", AsistentesController.update);

// Eliminar asistente (borrarlo de un evento)
router.delete("/:id", AsistentesController.remove);

export default router;
