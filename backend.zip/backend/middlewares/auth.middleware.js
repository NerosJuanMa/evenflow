// middlewares/auth.middleware.js
import jwt from "jsonwebtoken";

export function verifyToken(req, res, next) {
  const header = req.headers["authorization"];

  if (!header) {
    return res.status(401).json({ error: "Token no proporcionado" });
  }

  const token = header.split(" ")[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // Guardar info del usuario en req.user
    next();
  } catch (err) {
    return res.status(403).json({ error: "Token inválido" });
  }
}

export function isAdmin(req, res, next) {
  if (req.user.rol !== "admin") {
    return res.status(403).json({ error: "Acceso denegado: se requiere rol admin" });
  }
  next();
}

export function isSelfOrAdmin(req, res, next) {
  const { id } = req.params;

  if (req.user.rol === "admin" || req.user.id == id) {
    return next();
  }

  return res.status(403).json({ error: "Acceso denegado" });
}
